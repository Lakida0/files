
     __._        _.____   _.____   _.____   _.__    ____._    ____._
   _/  |/________\|_   \__\|_   \__\|_   \__\|__)__/  _ |/___/  __|/____
  _)   _/      /   /    /   /    /   /    /      (_   __|  (_____      (_
  \    \      /        /        /   /     \       /         /   /       /
  /_____\_____\________\________\___\______\______\_________\___________\
 - -diP--------------------------------------------------------------uP!- -

 
                           One Of Those Days
                       Released at Revision 2018
						   8 kb Intro compo
													 		

Credits
=======
Music: Booster
Synth, scripting, additional mentorizing: Blueberry
Code, scripting, etc: Psycho (psycho@loonies.dk)

Crinkler for compression
Rocket for scripting
Oidos synth for music
Internal shader compactor


Compatibility
=============
Windows 10 Creators update (I think)
DirectX 11.1, feature level 11_0


Tech
====
Two pass accelerated tile based raymarching (2-3x speed up in these scenes) - will do a writeup on this later...
Base landscape is a large texture
Simple postprocessing


Additional info
===============
http://www.loonies.dk
